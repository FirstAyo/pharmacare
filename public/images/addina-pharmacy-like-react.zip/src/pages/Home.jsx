import Hero from '../components/sections/Hero'
import ServiceStrip from '../components/sections/ServiceStrip'
import FeaturedProducts from '../components/sections/FeaturedProducts'
export default function Home(){return(<><Hero/><ServiceStrip/><FeaturedProducts/></>)}