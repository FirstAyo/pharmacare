import Section from '../components/ui/Section'
export default function Account(){return(<Section title='My Account'><div className='card'>Sign in / Sign up coming soon.</div></Section>)}